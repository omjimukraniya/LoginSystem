const router=require('express').Router()
const regc=require('../controllers/regcontroller')

router.post('/registration',regc.registration)
router.post('/login',regc.login)



module.exports=router