const Reg = require('../models/reg')


exports.registration = async (req, res) => {
      const { name, email, pass } = req.body
      try {
            const regCheck = await Reg.find({ email: email })
            if (regCheck === null) {
                  const record = new Reg({ username: name, email: email, password: pass })
                  record.save()
                  res.json({
                        status: 201,
                        apiData: record,
                        message: "Successfully Registered."
                  })
            } else {
                  res.json({
                        message: "Email Already Registered, Please Try Other Email."
                  })
            }
      } catch (error) {
            res.json({
                  status: 400,
                  message: error.message
            })
      }
}


exports.login = async (req, res) => {
      const { name, email, pass } = req.body
      try {
            const userCheck = await Reg.findOne({ username: name })
            if (userCheck !== null) {
                  if (userCheck.email === email) {
                        if (userCheck.password === pass) {
                              res.json({
                                    status: 201,
                                    apiData: userCheck,
                                    message: "Successfully Logined"
                              })
                        } else {
                              res.json({
                                    status: 400,
                                    message: "Worng Password"
                              })
                        }
                  } else {
                        res.json({
                              status: 400,
                              message: "Worng Email"
                        })
                  }
            } else {
                  res.json({
                        status: 400,
                        message: "Worng Username"
                  })
            }
      } catch (error) {
            res.json({
                  status: 500,
                  message: error.message
            })
      }
}