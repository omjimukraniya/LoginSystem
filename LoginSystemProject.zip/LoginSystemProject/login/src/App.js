import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Reg from './comp/Reg';
import Login from './comp/Login';

function App() {
  return ( 
    <Router>
      <Routes>
      <Route path='/' element={<Login />}></Route>
        <Route path='/reg' element={<Reg />}></Route>
      </Routes>
    </Router>
   );
}

export default App;