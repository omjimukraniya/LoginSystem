import { useState } from "react";
import { Link } from "react-router-dom";

function Reg() {

      const[name, setName]=useState('')
      const[email, setEmail]=useState('')
      const[pass, setPass]=useState('')
      const[message, setMessage]=useState('')


      function handleform(e){
            e.preventDefault()
            const data={name,email,pass}
            fetch('/api/registration',{
                  method:'POST',
                  headers:{'Content-Type':"application/json"},
                  body:JSON.stringify(data)
            }).then((result)=>{return result.json()}).then((data)=>{
                  //console.log(data)
                  if(data.status===201){
                        setMessage(data.message)
                  }else{
                        setMessage(data.message)
                  }
            })
      }

      return (
            <section id="reg">
                  <div className="container">
                        <div className="row justify-content-center">
                              <div className="col-md-4">
                                    <h2>!!  Signup Page  !!</h2>
                                    <p>{message}</p>
                                    <form onSubmit={(e)=>{handleform(e)}}>
                                          <label>User Name</label>
                                          <input type="text" className="form-control"
                                          value={name}
                                          onChange={(e)=>{setName(e.target.value)}}
                                          />
                                          <label>Email</label>
                                          <input type="email" className="form-control" 
                                          value={email}
                                          onChange={(e)=>{setEmail(e.target.value)}}
                                          />
                                          <label>Password</label>
                                          <input type="password" className="form-control" 
                                          value={pass}
                                          onChange={(e)=>{setPass(e.target.value)}}
                                          />
                                          <button type="submit" className="form-control btn btn-success mt-4">Register</button>
                                    </form>
                                    <div className="btn btn-primary mx-auto d-block mt-5"><Link to='/'><button className="btn btn-primary">If You Have Already Account? Click Here</button></Link></div>
                              </div>
                        </div>
                  </div>
            </section>
      );
}

export default Reg;