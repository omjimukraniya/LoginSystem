import { useState } from "react";
import { Link } from "react-router-dom";

function Login() {

      const[name, setName]=useState('')
      const[email, setEmail]=useState('')
      const[pass, setPass]=useState('')
      const[message, setMessage]=useState('')


      function handleform(e){
            e.preventDefault()
            const data={name,email,pass}
            fetch('/api/login',{
                  method:"POST",
                  headers:{'Content-Type':"application/json"},
                  body:JSON.stringify(data)
            }).then((result)=>{return result.json()}).then((data)=>{
                  console.log(data)
            })
      }

      return ( 
            <section id="reg">
                  <div className="container">
                        <div className="row justify-content-center">
                              <div className="col-md-4">
                                    <h2>!!  Login Here  !!</h2>
                                    <p>{message}</p>
                                    <form onSubmit={(e)=>{handleform(e)}}>
                                          <label>User Name</label>
                                          <input type="text" className="form-control"
                                          value={name}
                                          onChange={(e)=>{setName(e.target.value)}}
                                          />
                                          <label>Email</label>
                                          <input type="email" className="form-control" 
                                          value={email}
                                          onChange={(e)=>{setEmail(e.target.value)}}
                                          />
                                          <label>Password</label>
                                          <input type="password" className="form-control" 
                                          value={pass}
                                          onChange={(e)=>{setPass(e.target.value)}}
                                          />
                                          <button type="submit" className="form-control btn btn-primary mt-4">Login</button>
                                    </form>
                                    <div className="btn btn-success mx-auto d-block mt-5"><Link to='/reg'><button className="btn btn-success">If You Don't Have Account? Click Here</button></Link></div>
                              </div>
                        </div>
                  </div>
            </section>
       );
}

export default Login;